This is a sample readme file.
This file will be added to the zip file because it was added in the compile.json file:


  "zip": {
    "filename": "compiled_templates.zip",
    "files": [
      "readme.txt"
    ]
  }